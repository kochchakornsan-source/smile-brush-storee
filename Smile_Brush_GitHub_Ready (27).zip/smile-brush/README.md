# Smile Brush — Toothbrush Online Store

เว็บไซต์ตัวอย่างร้านแปรงสีฟัน Smile Brush พัฒนาด้วย React + Vite และ Vercel Functions พร้อมเชื่อม Google Sheets เป็นฐานข้อมูล

## คุณสมบัติ

- Landing page ภาษาไทย ดีไซน์ Modern Minimal
- สินค้าอย่างน้อย 2 SKU พร้อมราคา รูปภาพ และสต็อกคงเหลือ
- ค้นหาสินค้า ตะกร้าสินค้า และ Checkout
- บันทึกคำสั่งซื้อและรายละเอียดสินค้าใน Google Sheets
- หน้าแอดมินสำหรับดูคำสั่งซื้อและเปลี่ยนสถานะ
- พิมพ์ Picking List และใบจ่าหน้าพัสดุ
- รูปสินค้าเก็บไว้ใน `public/images/` แยกจาก Source Code

## โครงสร้าง Google Sheets

ชื่อแท็บและคอลัมน์ต้องตรงกับไฟล์แม่แบบใน `docs/Smile_Brush_Google_Sheets_Template.xlsx`

- `Products`: A SKU, B ชื่อสินค้า, C รายละเอียด, D ราคา, E สต็อกเริ่มต้น, F คงเหลือ, G URL รูป, H สถานะ
- `Orders`: A Order ID, B วันที่, C ชื่อลูกค้า, D โทรศัพท์, E ที่อยู่, F อำเภอ/เขต, G จังหวัด, H รหัสไปรษณีย์, I ยอดรวม, J สถานะ, K หมายเหตุ
- `Order_Details`: A Order ID, B SKU, C ชื่อสินค้า, D จำนวน, E ราคาต่อชิ้น, F รวม

## รันบนเครื่อง

1. ติดตั้ง Node.js รุ่น LTS
2. เปิด Terminal ในโฟลเดอร์โปรเจกต์
3. รัน `npm install`
4. คัดลอก `.env.example` เป็น `.env` และใส่ค่าจริงตามหัวข้อ Google Sheets
5. รัน `npm run dev`

## ตั้งค่า Google Sheets

1. อัปโหลดไฟล์แม่แบบใน `docs/` ไปยัง Google Drive แล้วเปิดด้วย Google Sheets
2. แปลงเป็น Google Sheets และตั้งชื่อแท็บตามรายการด้านบน (โดยเฉพาะ `Order_Details` ใช้ underscore)
3. เปิด Google Cloud Console สร้าง Project และเปิดใช้งาน Google Sheets API
4. สร้าง Service Account แล้วดาวน์โหลด JSON key
5. แชร์ Google Sheet ให้กับอีเมล `client_email` ของ Service Account โดยให้สิทธิ์ Editor
6. คัดลอก Spreadsheet ID จาก URL ของชีต
7. ตั้งค่า Environment Variables ใน Vercel:
   - `GOOGLE_SHEET_ID`: Spreadsheet ID
   - `GOOGLE_SERVICE_ACCOUNT_JSON`: เนื้อหา Service Account JSON ทั้งก้อนแบบบรรทัดเดียว
8. Redeploy หลังบันทึก Environment Variables

**ห้าม commit ไฟล์ Service Account JSON, `.env` หรือ private key ลง GitHub**

## Deploy บน GitHub + Vercel

1. สร้าง GitHub repository ชื่อ `smile-brush-store`
2. อัปโหลดไฟล์และโฟลเดอร์ทั้งหมดใน repository นี้
3. เข้า Vercel แล้วเลือก Add New → Project และ Import Git Repository
4. Framework Preset: Vite; Build Command: `npm run build`; Output Directory: `dist`
5. เพิ่ม Environment Variables ตามหัวข้อ Google Sheets
6. กด Deploy แล้วทดสอบการสั่งซื้อและหน้าจัดการคำสั่งซื้อ

## หมายเหตุด้านความปลอดภัย

โปรเจกต์นี้เป็นต้นแบบสำหรับการเรียนรู้ ก่อนใช้กับลูกค้าจริงควรเพิ่มการยืนยันตัวตนสำหรับหน้าแอดมินและ API ที่อ่าน/แก้ไขคำสั่งซื้อ, จำกัดการเรียก API, ตรวจสอบการชำระเงิน และกำหนดกระบวนการสำรองข้อมูล Google Sheets ห้ามเผยแพร่ข้อมูลลูกค้าจริงใน repository สาธารณะ
