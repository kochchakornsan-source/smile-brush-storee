import { sheetsClient, spreadsheetId, readRows } from './_sheets.js';

const ALLOWED = new Set(['รอแพ็ค', 'กำลังแพ็ค', 'จัดส่งแล้ว', 'ยกเลิก']);

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const { orderId, status } = req.body || {};
    if (!orderId || !ALLOWED.has(status)) return res.status(400).json({ error: 'ข้อมูลสถานะไม่ถูกต้อง' });
    const rows = await readRows('Orders!A:K');
    const index = rows.findIndex((row, i) => i > 0 && row[0] === orderId);
    if (index < 1) return res.status(404).json({ error: 'ไม่พบคำสั่งซื้อ' });
    const sheets = sheetsClient();
    // Orders column J is the order status in the Smile Brush template.
    await sheets.spreadsheets.values.update({
      spreadsheetId: spreadsheetId(), range: `Orders!J${index + 1}`,
      valueInputOption: 'USER_ENTERED', requestBody: { values: [[status]] },
    });
    return res.status(200).json({ ok: true });
  } catch (error) {
    return res.status(500).json({ error: error.message || 'อัปเดตสถานะไม่สำเร็จ' });
  }
}
