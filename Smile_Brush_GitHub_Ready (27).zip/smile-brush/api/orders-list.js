import { readRows } from './_sheets.js';

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const [orderRows, detailRows] = await Promise.all([
      readRows('Orders!A:K'),
      readRows('Order_Details!A:F'),
    ]);
    const items = detailRows.slice(1).map(row => ({
      orderId: row[0], sku: row[1], name: row[2], qty: Number(row[3] || 0),
      price: Number(row[4] || 0), subtotal: Number(row[5] || 0),
    }));
    const orders = orderRows.slice(1).filter(row => row[0]).reverse().map(row => ({
      id: row[0], date: row[1], name: row[2], phone: row[3],
      address: row[4], district: row[5], province: row[6], postcode: row[7],
      total: Number(row[8] || 0), status: row[9], note: row[10],
      items: items.filter(item => item.orderId === row[0]),
    }));
    return res.status(200).json({ orders });
  } catch (error) {
    return res.status(500).json({ error: error.message || 'โหลดคำสั่งซื้อไม่สำเร็จ' });
  }
}
