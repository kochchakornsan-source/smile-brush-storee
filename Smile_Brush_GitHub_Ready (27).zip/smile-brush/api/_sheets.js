import { google } from 'googleapis';
export function sheetsClient(){
  if(!process.env.GOOGLE_SERVICE_ACCOUNT_JSON || !process.env.GOOGLE_SHEET_ID) throw new Error('ยังไม่ได้ตั้งค่า Google Sheets กรุณากำหนด GOOGLE_SERVICE_ACCOUNT_JSON และ GOOGLE_SHEET_ID ใน Vercel');
  const credentials=JSON.parse(process.env.GOOGLE_SERVICE_ACCOUNT_JSON);
  const auth=new google.auth.GoogleAuth({credentials,scopes:['https://www.googleapis.com/auth/spreadsheets']});
  return google.sheets({version:'v4',auth});
}
export const spreadsheetId=()=>process.env.GOOGLE_SHEET_ID;
export async function readRows(range){const s=sheetsClient();const r=await s.spreadsheets.values.get({spreadsheetId:spreadsheetId(),range});return r.data.values||[];}
export async function appendRows(range,values){const s=sheetsClient();return s.spreadsheets.values.append({spreadsheetId:spreadsheetId(),range,valueInputOption:'USER_ENTERED',insertDataOption:'INSERT_ROWS',requestBody:{values}});}
