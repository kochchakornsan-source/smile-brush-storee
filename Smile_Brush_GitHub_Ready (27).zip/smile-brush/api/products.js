import { readRows } from './_sheets.js';

const demo = [
  { sku: 'SB-MINT', name: 'Fresh Mint Toothbrush', description: 'แปรงสีฟันขนนุ่ม ด้ามจับกระชับ ใช้ได้ทุกวัน', price: 89, stock: 120, image: '/images/brush-mint.svg' },
  { sku: 'SB-SOFT', name: 'Ultra Soft Toothbrush', description: 'ขนนุ่มพิเศษ อ่อนโยนต่อเหงือก เหมาะกับการแปรงประจำวัน', price: 99, stock: 85, image: '/images/brush-soft.svg' },
];

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  try {
    // Products columns: A SKU, B name, C description, D price, E opening stock, F remaining stock, G image URL, H status
    const rows = await readRows('Products!A:H');
    const products = rows.slice(1).filter(r => r[0]).map(r => ({
      sku: r[0], name: r[1], description: r[2], price: Number(r[3] || 0),
      stock: Number(r[5] ?? r[4] ?? 0), image: r[6] || '/images/brush-mint.svg',
    })).filter(p => p.stock >= 0);
    return res.status(200).json({ products: products.length ? products : demo, source: products.length ? 'sheets' : 'demo' });
  } catch (error) {
    return res.status(200).json({ products: demo, source: 'demo', setupRequired: true });
  }
}
