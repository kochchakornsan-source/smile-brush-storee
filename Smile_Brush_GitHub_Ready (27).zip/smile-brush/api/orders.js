import { appendRows, readRows } from './_sheets.js';

const clean = value => String(value ?? '').trim();

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const body = req.body || {};
    if (!Array.isArray(body.items) || !body.items.length || !clean(body.name) || !clean(body.phone) || !clean(body.address)) {
      return res.status(400).json({ error: 'กรุณากรอกข้อมูลผู้รับและสินค้าให้ครบ' });
    }

    // Verify SKU, price and remaining stock against the Products sheet; do not trust client prices.
    const productRows = await readRows('Products!A:H');
    const products = new Map(productRows.slice(1).filter(row => row[0]).map(row => [row[0], {
      sku: row[0], name: row[1], price: Number(row[3] || 0), stock: Number(row[5] ?? row[4] ?? 0),
    }]));

    const items = body.items.map(item => {
      const sku = clean(item.sku);
      const product = products.get(sku);
      const qty = Math.floor(Number(item.qty));
      if (!product || !Number.isFinite(qty) || qty < 1) throw new Error(`ไม่พบสินค้า หรือจำนวนไม่ถูกต้อง: ${sku}`);
      if (qty > product.stock) throw new Error(`สินค้า ${product.name} คงเหลือไม่เพียงพอ (เหลือ ${product.stock} ชิ้น)`);
      return { ...product, qty };
    });

    const orderId = `SB${Date.now().toString().slice(-9)}`;
    const createdAt = new Date().toISOString();
    const total = items.reduce((sum, item) => sum + item.qty * item.price, 0);

    // Orders columns A:K include a district field between address and province.
    await appendRows('Orders!A:K', [[
      orderId, createdAt, clean(body.name), clean(body.phone), clean(body.address),
      clean(body.district), clean(body.province), clean(body.postcode), total, 'รอแพ็ค', clean(body.note),
    ]]);
    await appendRows('Order_Details!A:F', items.map(item => [
      orderId, item.sku, item.name, item.qty, item.price, item.qty * item.price,
    ]));

    return res.status(200).json({ ok: true, orderId, total, createdAt });
  } catch (error) {
    return res.status(400).json({ error: error.message || 'บันทึกคำสั่งซื้อไม่สำเร็จ' });
  }
}
